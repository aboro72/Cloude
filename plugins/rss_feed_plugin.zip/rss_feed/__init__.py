"""
Heise RSS Feed Plugin for CloudService.
Displays latest news from heise.de on the dashboard.
"""

default_app_config = 'rss_feed.apps.RssFeedConfig'
